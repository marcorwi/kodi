import xbmc
import xbmcgui
import sys

# Inserisci il tuo URL streaming tra le virgolette
url = "https://nrf1.newradio.it:10216/stream"
# Inserisci il nome della tua radio
name = "Radio Web Italia"
# Inserisci il link alla tua icona (opzionale)
icon = "https://github.com/marcorwi/kodi/raw/refs/heads/main/icon.png"

def play_radio():
    # Crea l'oggetto che Kodi deve riprodurre
    listitem = xbmcgui.ListItem(label=name)
    listitem.setArt({'icon': icon, 'thumb': icon})
    listitem.setInfo('audio', {'title': name, 'mediatype': 'music'})
    
    # Questo comando forza Kodi ad avviare il player immediatamente
    xbmc.Player().play(item=url, listitem=listitem)

if __name__ == '__main__':
    play_radio()