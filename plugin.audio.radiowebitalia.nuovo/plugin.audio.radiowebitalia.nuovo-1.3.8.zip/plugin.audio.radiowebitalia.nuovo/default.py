import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os

# --- CONFIGURAZIONE ---
url = "https://nrf1.newradio.it:10216/stream"
name = "Radio Web Italia"
handle = int(sys.argv[1])

# Recupera il percorso locale dell'installazione
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')

# Punta al file icon.png che hai già messo nello ZIP
# Questo risolve il problema dell'icona mancante una volta per tutte
local_icon = os.path.join(addon_path, 'icon.png')

def play_radio():
    listitem = xbmcgui.ListItem(label=name)
    
    # Applica l'icona locale a tutti i tipi di visualizzazione
    listitem.setArt({
        'icon': local_icon,
        'thumb': local_icon,
        'poster': local_icon,
        'fanart': local_icon
    })
    
    # Info per il player e proprietà per lo STOP funzionante
    listitem.setInfo('audio', {'title': name, 'mediatype': 'music'})
    listitem.setProperty('IsPlayable', 'true')
    
    # Aggiunta alla lista (isFolder=False elimina le cartelle extra)
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=listitem, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    play_radio()