import xbmc
import xbmcgui

# --- CONFIGURAZIONE RADIO WEB ITALIA ---
url = "https://nrf1.newradio.it:10216/stream"
name = "Radio Web Italia"
icon = "https://raw.githubusercontent.com/marcorwi/kodi/main/icon.png"
# ---------------------------------------

def play_radio():
    try:
        # Crea l'elemento per il player di Kodi
        listitem = xbmcgui.ListItem(label=name)
        
        # Imposta l'icona e i metadati audio
        listitem.setArt({'icon': icon, 'thumb': icon})
        listitem.setInfo('audio', {'title': name, 'mediatype': 'music'})
        
        # Notifica di avvio (opzionale, utile per l'utente)
        xbmcgui.Dialog().notification('Radio Web Italia', 'Avvio streaming...', icon, 3000)
        
        # Comando di riproduzione forzata
        xbmc.Player().play(item=url, listitem=listitem)
        
    except Exception as e:
        # In caso di errore critico, mostra un messaggio a video
        xbmcgui.Dialog().ok("Errore Radio", f"Impossibile riprodurre lo stream: {str(e)}")

if __name__ == '__main__':
    play_radio()