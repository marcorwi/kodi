import xbmc
import xbmcgui
import xbmcplugin
import sys

# --- CONFIGURAZIONE ---
url = "https://nrf1.newradio.it:10216/stream"
name = "Radio Web Italia"
icon = "https://raw.githubusercontent.com/marcorwi/kodi/main/icon.png"

def play_radio():
    # 1. Crea l'oggetto per il player
    listitem = xbmcgui.ListItem(label=name)
    listitem.setArt({'icon': icon, 'thumb': icon})
    listitem.setInfo('audio', {'title': name, 'mediatype': 'music'})
    
    # 2. Avvia la musica
    xbmc.Player().play(item=url, listitem=listitem)
    
    # 3. IL SEGRETO: Dice a Kodi che la "cartella" è finita e non deve mostrare altro
    # Prende l'ID del plugin dal sistema per chiudere la visualizzazione
    try:
        handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
    except:
        pass

if __name__ == '__main__':
    play_radio()