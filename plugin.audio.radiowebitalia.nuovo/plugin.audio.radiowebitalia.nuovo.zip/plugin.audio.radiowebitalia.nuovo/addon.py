import xbmcgui
import xbmcplugin
import sys
import os
import xbmcaddon

# Recuperiamo il percorso esatto della cartella dell'addon
addon = xbmcaddon.Addon()
path = addon.getAddonInfo('path')
# Costruiamo il percorso completo dell'icona
icon_path = os.path.join(path, 'icon.png')

STREAM_URL = "https://nrf1.newradio.it:10216/stream"

def main():
    handle = int(sys.argv[1])
    list_item = xbmcgui.ListItem(label="[COLOR blue]▶[/COLOR] Radio Web Italia")
    
    # Usiamo il percorso assoluto per l'immagine
    list_item.setArt({'icon': icon_path, 'thumb': icon_path, 'poster': icon_path})
    
    list_item.setInfo('audio', {'title': "Radio Web Italia", 'artist': "SI.RA.IN. ODV"})
    list_item.setProperty('IsPlayable', 'true')
    
    xbmcplugin.addDirectoryItem(handle=handle, url=STREAM_URL, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    main()