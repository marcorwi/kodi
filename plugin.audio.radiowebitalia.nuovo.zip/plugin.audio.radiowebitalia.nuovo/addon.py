import xbmcgui
import xbmcplugin
import sys

# --- CONFIGURAZIONE ---
STREAM_URL = 'IL_TUO_LINK_STREAMING_QUI' # Metti qui il link della radio (es. http://.../stream)
LOG_NOME = 'Radio Web Italia'

def play_radio():
    # Crea l'oggetto per il player
    listitem = xbmcgui.ListItem(name=LOG_NOME)
    listitem.setInfo('video', {'title': LOG_NOME, 'genre': 'Radio'}) # Info base
    listitem.setArt({'icon': 'icon.png'})
    
    # Forza Kodi a far partire lo streaming
    xbmc.Player().play(STREAM_URL, listitem)

if __name__ == '__main__':
    play_radio()